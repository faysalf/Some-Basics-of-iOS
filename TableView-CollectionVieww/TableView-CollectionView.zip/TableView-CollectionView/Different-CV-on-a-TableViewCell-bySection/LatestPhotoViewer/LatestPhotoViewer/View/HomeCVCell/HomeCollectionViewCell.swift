//
//  HomeCollectionViewCell.swift
//  LatestPhotoViewer
//
//  Created by Md. Faysal Ahmed on 13/11/22.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var img: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
