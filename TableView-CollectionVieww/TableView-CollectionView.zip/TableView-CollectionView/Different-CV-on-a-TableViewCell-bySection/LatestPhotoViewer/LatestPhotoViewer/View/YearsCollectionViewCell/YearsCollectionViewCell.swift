//
//  YearsCollectionViewCell.swift
//  LatestPhotoViewer
//
//  Created by Md. Faysal Ahmed on 13/11/22.
//

import UIKit

class YearsCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var img: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
