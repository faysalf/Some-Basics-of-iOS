//
//  DetailsViewController.swift
//  LiveWallpaperr
//
//  Created by Md. Faysal Ahmed on 19/9/22.
//

import UIKit

class DetailsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func BttnAction(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    

}
