//
//  HomeCVCell.swift
//  DemoApp
//
//  Created by Md. Faysal Ahmed on 15/11/22.
//

import UIKit

class HomeCVCell: UICollectionViewCell {

    @IBOutlet weak var img: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
